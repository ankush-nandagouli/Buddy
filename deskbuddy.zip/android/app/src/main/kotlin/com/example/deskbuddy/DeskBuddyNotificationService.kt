
package com.example.deskbuddy

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class DeskBuddyNotificationService :
    NotificationListenerService() {

    companion object {

        private const val TAG =
            "DeskBuddyNotification"

        /*
         * DeskBuddy's own notification.
         */
        private const val OWN_PACKAGE =
            "com.example.deskbuddy"
    }

    // ============================================================
    // Listener connected
    // ============================================================

    override fun onListenerConnected() {

        super.onListenerConnected()

        Log.d(
            TAG,
            "================================"
        )

        Log.d(
            TAG,
            "DESKBUDDY NOTIFICATION LISTENER CONNECTED"
        )

        Log.d(
            TAG,
            "================================"
        )

        /*
         * Initialize native BLE.
         */
        DeskBuddyBleManager.initialize(
            applicationContext
        )

        /*
         * Connect to saved ESP32.
         */
        DeskBuddyBleManager.connect()

        /*
         * Process notifications already present.
         *
         * This is useful after the phone reconnects
         * or Android restarts the listener service.
         */
        try {

            val notifications =
                activeNotifications

            Log.d(
                TAG,
                "Existing notifications: "
                    + "${notifications?.size ?: 0}"
            )

            notifications?.forEach {
                processNotification(it)
            }

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Could not read active notifications",
                e
            )
        }
    }

    // ============================================================
    // Listener disconnected
    // ============================================================

    override fun onListenerDisconnected() {

        super.onListenerDisconnected()

        Log.w(
            TAG,
            "Notification listener disconnected"
        )
    }

    // ============================================================
    // NEW notification
    // ============================================================

    override fun onNotificationPosted(
        sbn: StatusBarNotification
    ) {

        Log.d(
            TAG,
            ""
        )

        Log.d(
            TAG,
            "================================"
        )

        Log.d(
            TAG,
            "NEW NOTIFICATION"
        )

        Log.d(
            TAG,
            "Package: ${sbn.packageName}"
        )

        Log.d(
            TAG,
            "Key: ${sbn.key}"
        )

        Log.d(
            TAG,
            "================================"
        )

        processNotification(sbn)
    }

    // ============================================================
    // Notification processing
    // ============================================================

    private fun processNotification(
        sbn: StatusBarNotification
    ) {

        val packageName =
            sbn.packageName

        /*
         * Don't capture DeskBuddy's own
         * foreground notification.
         */
        if (
            packageName ==
            applicationContext.packageName
        ) {

            return
        }

        /*
         * Check whether user selected this app.
         */
        if (
            !isPackageSelected(
                packageName
            )
        ) {

            Log.d(
                TAG,
                "App not selected: "
                    + packageName
            )

            return
        }

        val notification =
            sbn.notification
                ?: return

        /*
         * Ignore notification group summaries.
         */
        if (
            notification.flags and
            Notification.FLAG_GROUP_SUMMARY
            != 0
        ) {

            Log.d(
                TAG,
                "Ignoring group summary"
            )

            return
        }

        val extras =
            notification.extras

        val title =
            extractTitle(extras)

        val text =
            extractMessage(notification)

        Log.d(
            TAG,
            "Title: $title"
        )

        Log.d(
            TAG,
            "Message: $text"
        )

        /*
         * Nothing useful to display.
         */
        if (
            title.isBlank() &&
            text.isBlank()
        ) {

            Log.d(
                TAG,
                "No readable notification content"
            )

            return
        }

        val payload =
            buildPayload(
                title,
                text
            )

        if (payload.isBlank()) {
            return
        }

        /*
         * Prevent Android/WhatsApp from causing
         * duplicate display events.
         */
        if (
            DeskBuddyNotificationDeduplicator
                .isDuplicate(payload)
        ) {

            Log.d(
                TAG,
                "Duplicate ignored"
            )

            return
        }

        Log.d(
            TAG,
            "--------------------------------"
        )

        Log.d(
            TAG,
            "FORWARDING TO ESP32:"
        )

        Log.d(
            TAG,
            payload
        )

        Log.d(
            TAG,
            "--------------------------------"
        )

        /*
         * Native BLE.
         *
         * Flutter does NOT need to be running.
         */
        DeskBuddyBleManager
            .sendNotification(
                payload
            )
    }

    // ============================================================
    // Title extraction
    // ============================================================

    private fun extractTitle(
        extras: Bundle
    ): String {

        val title =
            extras.getCharSequence(
                Notification.EXTRA_TITLE
            )
                ?.toString()
                ?.trim()

        if (
            !title.isNullOrBlank()
        ) {

            return title
        }

        val conversationTitle =
            extras.getCharSequence(
                Notification.EXTRA_CONVERSATION_TITLE
            )
                ?.toString()
                ?.trim()

        return conversationTitle ?: ""
    }

    // ============================================================
    // Message extraction
    // ============================================================

    private fun extractMessage(
        notification: Notification
    ): String {

        val extras =
            notification.extras

        /*
         * --------------------------------------------------------
         * 1. MessagingStyle
         *
         * This is especially important for messaging apps.
         * --------------------------------------------------------
         */

        try {

            val messagingStyle =
                Notification.MessagingStyle
                    .extractMessagingStyleFromNotification(
                        notification
                    )

            if (
                messagingStyle != null
            ) {

                val messages =
                    messagingStyle.messages

                if (
                    messages.isNotEmpty()
                ) {

                    val latest =
                        messages.last()

                    val text =
                        latest.text
                            ?.toString()
                            ?.trim()

                    if (
                        !text.isNullOrBlank()
                    ) {

                        return text
                    }
                }
            }

        } catch (e: Exception) {

            Log.e(
                TAG,
                "MessagingStyle extraction failed",
                e
            )
        }

        /*
         * --------------------------------------------------------
         * 2. Normal notification text
         * --------------------------------------------------------
         */

        val text =
            extras.getCharSequence(
                Notification.EXTRA_TEXT
            )
                ?.toString()
                ?.trim()

        if (
            !text.isNullOrBlank()
        ) {

            return text
        }

        /*
         * --------------------------------------------------------
         * 3. Big text
         * --------------------------------------------------------
         */

        val bigText =
            extras.getCharSequence(
                Notification.EXTRA_BIG_TEXT
            )
                ?.toString()
                ?.trim()

        if (
            !bigText.isNullOrBlank()
        ) {

            return bigText
        }

        /*
         * --------------------------------------------------------
         * 4. Inbox-style lines
         * --------------------------------------------------------
         */

        val lines =
            extras.getCharSequenceArray(
                Notification.EXTRA_TEXT_LINES
            )

        if (
            lines != null &&
            lines.isNotEmpty()
        ) {

            return lines
                .joinToString(" ") {
                    it.toString()
                }
                .trim()
        }

        return ""
    }

    // ============================================================
    // Build final display message
    // ============================================================

    private fun buildPayload(
        title: String,
        text: String
    ): String {

        val cleanTitle =
            title.trim()

        val cleanText =
            text.trim()

        return when {

            cleanTitle.isNotEmpty() &&
                    cleanText.isNotEmpty() -> {

                "$cleanTitle: $cleanText"
            }

            cleanText.isNotEmpty() -> {

                cleanText
            }

            cleanTitle.isNotEmpty() -> {

                cleanTitle
            }

            else -> {
                ""
            }
        }
    }

    // ============================================================
    // Selected application
    // ============================================================

    private fun isPackageSelected(
        packageName: String
    ): Boolean {

        val prefs =
            getSharedPreferences(
                "deskbuddy",
                MODE_PRIVATE
            )

        /*
         * If the user has never configured the app,
         * WhatsApp is enabled by default.
         */
        val defaults =
            setOf(
                "com.whatsapp",
                "com.whatsapp.w4b"
            )

        val selected =
            prefs.getStringSet(
                "selected_packages",
                defaults
            )

        return selected?.contains(
            packageName
        ) ?: false
    }
}
