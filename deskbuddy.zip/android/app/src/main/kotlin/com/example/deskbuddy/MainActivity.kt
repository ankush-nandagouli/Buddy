package com.example.deskbuddy

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    companion object {
        private const val CHANNEL = "deskbuddy/native"
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL
        ).setMethodCallHandler { call, result ->

            when (call.method) {

                "isNotificationAccessGranted" -> {
                    result.success(isNotificationAccessGranted())
                }

                "openNotificationAccess" -> {
                    try {
                        val intent = Intent(
                            Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
                        )
                        startActivity(intent)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error(
                            "OPEN_NOTIFICATION_SETTINGS",
                            e.message,
                            null
                        )
                    }
                }

                "setEsp32Address" -> {
                    val address = call.argument<String>("address")

                    if (address.isNullOrBlank()) {
                        result.error(
                            "INVALID_ADDRESS",
                            "ESP32 Bluetooth address is missing",
                            null
                        )
                    } else {
                        DeskBuddyBleManager.setEsp32Address(
                            applicationContext,
                            address
                        )

                        result.success(true)
                    }
                }

                "sendTestNotification" -> {
                    val message =
                        call.argument<String>("message")
                            ?: "Desk Buddy test"

                    DeskBuddyBleManager.sendNotification(
                        applicationContext,
                        message
                    )

                    result.success(true)
                }

                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    private fun isNotificationAccessGranted(): Boolean {
        val notificationManager =
            getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        val componentName = ComponentName(
            this,
            DeskBuddyNotificationService::class.java
        )

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            notificationManager.isNotificationListenerAccessGranted(
                componentName
            )
        } else {
            false
        }
    }
}