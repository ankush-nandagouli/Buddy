
package com.example.deskbuddy

import android.content.ComponentName
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val CHANNEL =
        "deskbuddy/native"

    override fun configureFlutterEngine(
        flutterEngine: FlutterEngine
    ) {

        super.configureFlutterEngine(
            flutterEngine
        )

        MethodChannel(
            flutterEngine
                .dartExecutor
                .binaryMessenger,
            CHANNEL
        ).setMethodCallHandler {
                call,
                result ->

            when (call.method) {

                // =================================================
                // Check Notification Access
                // =================================================

                "isNotificationAccessGranted" -> {

                    val component =
                        ComponentName(
                            this,
                            DeskBuddyNotificationService::class.java
                        )

                    val enabled =
                        NotificationListenerService
                            .isNotificationListenerAccessGranted(
                                this,
                                component
                            )

                    result.success(enabled)
                }

                // =================================================
                // Open Android Notification Access
                // =================================================

                "openNotificationAccess" -> {

                    try {

                        val intent =
                            Intent(
                                Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
                            )

                        startActivity(intent)

                        result.success(true)

                    } catch (e: Exception) {

                        result.error(
                            "SETTINGS_ERROR",
                            e.message,
                            null
                        )
                    }
                }

                // =================================================
                // Save ESP32 address
                // =================================================

                "setEsp32Address" -> {

                    val address =
                        call.argument<String>(
                            "address"
                        )

                    if (
                        address.isNullOrBlank()
                    ) {

                        result.error(
                            "INVALID_ADDRESS",
                            "ESP32 address is empty",
                            null
                        )

                        return@setMethodCallHandler
                    }

                    DeskBuddyBleManager
                        .initialize(
                            applicationContext
                        )

                    DeskBuddyBleManager
                        .setDeviceAddress(
                            address
                        )

                    result.success(true)
                }

                else -> {
                    result.notImplemented()
                }
            }
        }
    }
}
