package com.example.deskbuddy

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

object DeskBuddyBleManager {

    private const val TAG = "DeskBuddyBLE"

    private const val SERVICE_UUID_STRING =
        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"

    private const val CHARACTERISTIC_UUID_STRING =
        "beb5483e-36e1-4688-b7f5-ea07361b26a8"

    private val serviceUuid: UUID =
        UUID.fromString(SERVICE_UUID_STRING)

    private val characteristicUuid: UUID =
        UUID.fromString(CHARACTERISTIC_UUID_STRING)

    private const val PREFS_NAME = "desk_buddy"
    private const val PREF_ESP32_ADDRESS = "esp32_address"

    private const val MAX_QUEUE_SIZE = 20

    /*
     * Your current ESP32 sketch does NOT implement packet
     * reassembly. Therefore keep every BLE write <= 20 bytes.
     */
    private const val MAX_BLE_PAYLOAD_BYTES = 20

    private const val RECONNECT_DELAY_MS = 2000L

    private val handler =
        Handler(Looper.getMainLooper())

    private val messageQueue =
        ConcurrentLinkedQueue<String>()

    private var applicationContext: Context? = null

    private var bluetoothGatt: BluetoothGatt? = null

    private var notificationCharacteristic:
        BluetoothGattCharacteristic? = null

    private var isConnected = false
    private var isConnecting = false
    private var writeInProgress = false

    // ---------------------------------------------------------------------
    // PUBLIC API
    // ---------------------------------------------------------------------

    fun setEsp32Address(
        context: Context,
        address: String
    ) {
        applicationContext =
            context.applicationContext

        if (!BluetoothAdapter.checkBluetoothAddress(address)) {
            android.util.Log.e(
                TAG,
                "Invalid Bluetooth address: $address"
            )
            return
        }

        context
            .getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                PREF_ESP32_ADDRESS,
                address
            )
            .apply()

        connect()
    }

    fun sendNotification(
        context: Context,
        message: String
    ) {
        applicationContext =
            context.applicationContext

        val cleanMessage =
            message
                .replace("\n", " ")
                .replace("\r", " ")
                .replace(Regex("\\s+"), " ")
                .trim()

        if (cleanMessage.isBlank()) {
            return
        }

        /*
         * Prevent unlimited queue growth.
         */
        if (messageQueue.size >= MAX_QUEUE_SIZE) {
            messageQueue.poll()
        }

        messageQueue.offer(cleanMessage)

        android.util.Log.d(
            TAG,
            "Queued notification: $cleanMessage"
        )

        /*
         * Start BLE connection if required.
         */
        connect()

        /*
         * If already connected, attempt immediately.
         */
        handler.post {
            processQueue()
        }
    }

    // ---------------------------------------------------------------------
    // STORED ESP32 ADDRESS
    // ---------------------------------------------------------------------

    private fun getSavedAddress(): String? {

        val context =
            applicationContext
                ?: return null

        return context
            .getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
            )
            .getString(
                PREF_ESP32_ADDRESS,
                null
            )
    }

    // ---------------------------------------------------------------------
    // BLUETOOTH PERMISSIONS
    // ---------------------------------------------------------------------

    private fun hasBluetoothConnectPermission(
        context: Context?
    ): Boolean {

        if (context == null) {
            return false
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return true
        }

        return context.checkSelfPermission(
            Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
    }

    // ---------------------------------------------------------------------
    // CONNECT
    // ---------------------------------------------------------------------

    @SuppressLint("MissingPermission")
    private fun connect() {

        val context =
            applicationContext
                ?: return

        if (isConnected || isConnecting) {
            return
        }

        if (!hasBluetoothConnectPermission(context)) {
            android.util.Log.e(
                TAG,
                "BLUETOOTH_CONNECT permission not granted"
            )
            return
        }

        val address =
            getSavedAddress()
                ?: run {
                    android.util.Log.d(
                        TAG,
                        "No ESP32 address configured"
                    )
                    return
                }

        if (!BluetoothAdapter.checkBluetoothAddress(address)) {
            android.util.Log.e(
                TAG,
                "Stored ESP32 address is invalid: $address"
            )
            return
        }

        val bluetoothManager =
            context.getSystemService(
                Context.BLUETOOTH_SERVICE
            ) as? BluetoothManager
                ?: run {
                    android.util.Log.e(
                        TAG,
                        "BluetoothManager unavailable"
                    )
                    return
                }

        val bluetoothAdapter =
            bluetoothManager.adapter
                ?: run {
                    android.util.Log.e(
                        TAG,
                        "BluetoothAdapter unavailable"
                    )
                    return
                }

        if (!bluetoothAdapter.isEnabled) {
            android.util.Log.e(
                TAG,
                "Bluetooth is disabled"
            )
            return
        }

        val device: BluetoothDevice =
            try {
                bluetoothAdapter.getRemoteDevice(address)
            } catch (e: IllegalArgumentException) {
                android.util.Log.e(
                    TAG,
                    "Unable to get Bluetooth device",
                    e
                )
                return
            }

        isConnecting = true

        android.util.Log.d(
            TAG,
            "Connecting to ESP32: $address"
        )

        /*
         * false = do not automatically reconnect at the
         * framework level. We handle reconnect ourselves.
         */
        bluetoothGatt =
            device.connectGatt(
                context,
                false,
                gattCallback,
                BluetoothDevice.TRANSPORT_LE
            )
    }

    // ---------------------------------------------------------------------
    // PROCESS QUEUE
    // ---------------------------------------------------------------------

    @SuppressLint("MissingPermission")
    private fun processQueue() {

        if (!isConnected) {
            return
        }

        if (writeInProgress) {
            return
        }

        val gatt =
            bluetoothGatt
                ?: return

        val characteristic =
            notificationCharacteristic
                ?: return

        val message =
            messageQueue.peek()
                ?: return

        /*
         * The current ESP32 application does not have a
         * fragmentation/reassembly protocol.
         *
         * Convert the notification into a <=20 byte payload.
         */
        val payload =
            createBlePayload(message)

        if (payload.isEmpty()) {
            messageQueue.poll()
            processQueue()
            return
        }

        writeInProgress = true

        android.util.Log.d(
            TAG,
            "Sending BLE payload: $payload"
        )

        val success: Boolean

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            success =
                gatt.writeCharacteristic(
                    characteristic,
                    payload,
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                ) == BluetoothGatt.GATT_SUCCESS

        } else {

            @Suppress("DEPRECATION")
            characteristic.writeType =
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

            @Suppress("DEPRECATION")
            success =
                gatt.writeCharacteristic(
                    characteristic
                )
        }

        if (!success) {

            writeInProgress = false

            android.util.Log.e(
                TAG,
                "Failed to start BLE characteristic write"
            )

            /*
             * Retry after a short delay.
             */
            handler.postDelayed(
                {
                    if (isConnected) {
                        processQueue()
                    }
                },
                500L
            )
        }
    }

    // ---------------------------------------------------------------------
    // BLE PAYLOAD
    // ---------------------------------------------------------------------

    private fun createBlePayload(
        message: String
    ): ByteArray {

        /*
         * UTF-8 characters can occupy more than one byte.
         * We therefore truncate by BYTE count, not Kotlin
         * String length.
         */
        val fullData =
            message.toByteArray(
                Charsets.UTF_8
            )

        if (fullData.size <= MAX_BLE_PAYLOAD_BYTES) {
            return fullData
        }

        /*
         * Try to preserve a small readable preview.
         */
        val suffix =
            "...".toByteArray(
                Charsets.UTF_8
            )

        val maximumTextBytes =
            MAX_BLE_PAYLOAD_BYTES -
            suffix.size

        if (maximumTextBytes <= 0) {
            return suffix.take(
                MAX_BLE_PAYLOAD_BYTES
            ).toByteArray()
        }

        var text =
            String(
                fullData,
                0,
                maximumTextBytes,
                Charsets.UTF_8
            )

        /*
         * UTF-8 truncation can theoretically cut a multibyte
         * sequence. Re-encode and shorten until valid.
         */
        while (
            text.toByteArray(Charsets.UTF_8).size >
            maximumTextBytes &&
            text.isNotEmpty()
        ) {
            text = text.dropLast(1)
        }

        return (
            text + "..."
        ).toByteArray(
            Charsets.UTF_8
        ).take(
            MAX_BLE_PAYLOAD_BYTES
        ).toByteArray()
    }

    // ---------------------------------------------------------------------
    // GATT CALLBACK
    // ---------------------------------------------------------------------

    private val gattCallback =
        object : BluetoothGattCallback() {

            override fun onConnectionStateChange(
                gatt: BluetoothGatt,
                status: Int,
                newState: Int
            ) {

                handler.post {

                    if (
                        status == BluetoothGatt.GATT_SUCCESS &&
                        newState ==
                        BluetoothProfile.STATE_CONNECTED
                    ) {

                        android.util.Log.d(
                            TAG,
                            "ESP32 BLE connected"
                        )

                        isConnecting = false
                        isConnected = true
                        writeInProgress = false

                        bluetoothGatt = gatt

                        if (
                            !hasBluetoothConnectPermission(
                                applicationContext
                            )
                        ) {
                            android.util.Log.e(
                                TAG,
                                "Missing BLUETOOTH_CONNECT permission"
                            )
                            cleanupGatt(gatt)
                            return@post
                        }

                        val discoveryStarted =
                            try {
                                gatt.discoverServices()
                            } catch (e: Exception) {
                                android.util.Log.e(
                                    TAG,
                                    "Service discovery exception",
                                    e
                                )
                                false
                            }

                        if (!discoveryStarted) {
                            android.util.Log.e(
                                TAG,
                                "Could not start service discovery"
                            )
                        }

                    } else {

                        android.util.Log.d(
                            TAG,
                            "ESP32 disconnected. status=$status state=$newState"
                        )

                        isConnected = false
                        isConnecting = false
                        writeInProgress = false

                        notificationCharacteristic = null

                        cleanupGatt(gatt)

                        /*
                         * Only reconnect when there are messages
                         * waiting to be delivered.
                         */
                        if (!messageQueue.isEmpty()) {
                            scheduleReconnect()
                        }
                    }
                }
            }

            override fun onServicesDiscovered(
                gatt: BluetoothGatt,
                status: Int
            ) {

                handler.post {

                    if (
                        status != BluetoothGatt.GATT_SUCCESS
                    ) {

                        android.util.Log.e(
                            TAG,
                            "Service discovery failed: $status"
                        )

                        scheduleReconnect()
                        return@post
                    }

                    android.util.Log.d(
                        TAG,
                        "BLE services discovered"
                    )

                    val service =
                        gatt.getService(
                            serviceUuid
                        )

                    if (service == null) {

                        android.util.Log.e(
                            TAG,
                            "Desk Buddy service not found: $SERVICE_UUID_STRING"
                        )

                        scheduleReconnect()
                        return@post
                    }

                    val characteristic =
                        service.getCharacteristic(
                            characteristicUuid
                        )

                    if (characteristic == null) {

                        android.util.Log.e(
                            TAG,
                            "Desk Buddy characteristic not found: $CHARACTERISTIC_UUID_STRING"
                        )

                        scheduleReconnect()
                        return@post
                    }

                    notificationCharacteristic =
                        characteristic

                    android.util.Log.d(
                        TAG,
                        "Desk Buddy BLE characteristic ready"
                    )

                    processQueue()
                }
            }

            override fun onCharacteristicWrite(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
            ) {

                handler.post {

                    writeInProgress = false

                    if (
                        status ==
                        BluetoothGatt.GATT_SUCCESS
                    ) {

                        android.util.Log.d(
                            TAG,
                            "BLE notification delivered successfully"
                        )

                        /*
                         * Remove the exact message that was
                         * successfully sent.
                         */
                        messageQueue.poll()

                        processQueue()

                    } else {

                        android.util.Log.e(
                            TAG,
                            "BLE characteristic write failed: $status"
                        )

                        /*
                         * Keep the message in the queue so it can
                         * be retried.
                         */
                        handler.postDelayed(
                            {
                                if (isConnected) {
                                    processQueue()
                                }
                            },
                            500L
                        )
                    }
                }
            }
        }

    // ---------------------------------------------------------------------
    // RECONNECT
    // ---------------------------------------------------------------------

    private fun scheduleReconnect() {

        handler.postDelayed(
            {
                if (
                    !isConnected &&
                    !isConnecting &&
                    !messageQueue.isEmpty()
                ) {
                    connect()
                }
            },
            RECONNECT_DELAY_MS
        )
    }

    // ---------------------------------------------------------------------
    // CLEANUP
    // ---------------------------------------------------------------------

    @SuppressLint("MissingPermission")
    private fun cleanupGatt(
        gatt: BluetoothGatt
    ) {

        try {
            gatt.close()
        } catch (e: Exception) {
            android.util.Log.e(
                TAG,
                "Error closing GATT",
                e
            )
        }

        if (bluetoothGatt === gatt) {
            bluetoothGatt = null
        }
    }
}