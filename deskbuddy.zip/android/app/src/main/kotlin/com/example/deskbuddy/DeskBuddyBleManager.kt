package com.example.deskbuddy

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

object DeskBuddyBleManager {

    private const val SERVICE_UUID_STRING =
        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"

    private const val CHARACTERISTIC_UUID_STRING =
        "beb5483e-36e1-4688-b7f5-ea07361b26a8"

    private val SERVICE_UUID =
        UUID.fromString(SERVICE_UUID_STRING)

    private val CHARACTERISTIC_UUID =
        UUID.fromString(CHARACTERISTIC_UUID_STRING)

    private const val PREFS_NAME = "desk_buddy"
    private const val PREF_ESP32_ADDRESS = "esp32_address"

    private const val MAX_QUEUE_SIZE = 20

    private val handler =
        Handler(Looper.getMainLooper())

    private val messageQueue =
        ConcurrentLinkedQueue<String>()

    private var bluetoothGatt: BluetoothGatt? = null
    private var notificationCharacteristic:
        BluetoothGattCharacteristic? = null

    private var connected = false
    private var connecting = false

    private var applicationContext: Context? = null

    fun setEsp32Address(
        context: Context,
        address: String
    ) {

        applicationContext =
            context.applicationContext

        context
            .getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
            )
            .edit()
            .putString(
                PREF_ESP32_ADDRESS,
                address
            )
            .apply()

        connect()
    }

    fun sendNotification(
        context: Context,
        message: String
    ) {

        applicationContext =
            context.applicationContext

        if (message.isBlank()) {
            return
        }

        if (messageQueue.size >= MAX_QUEUE_SIZE) {
            messageQueue.poll()
        }

        messageQueue.offer(message)

        connect()

        handler.post {
            processQueue()
        }
    }

    private fun getSavedAddress(): String? {

        val context =
            applicationContext ?: return null

        return context
            .getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
            )
            .getString(
                PREF_ESP32_ADDRESS,
                null
            )
    }

    @SuppressLint("MissingPermission")
    private fun connect() {

        val context =
            applicationContext ?: return

        if (connected || connecting) {
            return
        }

        val address =
            getSavedAddress()
                ?: return

        if (!hasBluetoothPermission(context)) {
            android.util.Log.e(
                "DeskBuddyBLE",
                "Bluetooth permission not granted"
            )
            return
        }

        val bluetoothManager =
            context.getSystemService(
                Context.BLUETOOTH_SERVICE
            ) as BluetoothManager

        val adapter =
            bluetoothManager.adapter
                ?: return

        if (!adapter.isEnabled) {
            android.util.Log.e(
                "DeskBuddyBLE",
                "Bluetooth is disabled"
            )
            return
        }

        val device =
            try {
                adapter.getRemoteDevice(address)
            } catch (e: IllegalArgumentException) {
                android.util.Log.e(
                    "DeskBuddyBLE",
                    "Invalid ESP32 address",
                    e
                )
                return
            }

        connecting = true

        android.util.Log.d(
            "DeskBuddyBLE",
            "Connecting to ESP32: $address"
        )

        bluetoothGatt =
            device.connectGatt(
                context,
                false,
                gattCallback
            )
    }

    @SuppressLint("MissingPermission")
    private fun processQueue() {

        if (!connected) {
            return
        }

        val characteristic =
            notificationCharacteristic
                ?: return

        if (messageQueue.isEmpty()) {
            return
        }

        val message =
            messageQueue.peek()
                ?: return

        /*
         * ESP32 currently expects the entire notification
         * in one characteristic write.
         *
         * Keep it comfortably below the default BLE
         * ATT payload size.
         */
        val safeMessage =
            message
                .replace("\n", " ")
                .replace("\r", " ")
                .take(180)

        val data =
            safeMessage.toByteArray(
                Charsets.UTF_8
            )

        /*
         * Default ATT payload is normally 20 bytes.
         *
         * For your current ESP32 sketch, we should not
         * split the notification because the ESP32 does
         * not implement packet reassembly.
         *
         * Therefore only send when the negotiated
         * characteristic write size can accommodate it.
         */
        if (data.size > 20) {

            val shortened =
                safeMessage
                    .take(18) + ".."

            val shortenedData =
                shortened.toByteArray(
                    Charsets.UTF_8
                )

            writeCharacteristic(
                characteristic,
                shortenedData
            )

        } else {

            writeCharacteristic(
                characteristic,
                data
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun writeCharacteristic(
        characteristic: BluetoothGattCharacteristic,
        data: ByteArray
    ) {

        val gatt =
            bluetoothGatt
                ?: return

        characteristic.value = data

        val result =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                gatt.writeCharacteristic(
                    characteristic,
                    data,
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                )
            } else {
                @Suppress("DEPRECATION")
                characteristic.writeType =
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

                @Suppress("DEPRECATION")
                gatt.writeCharacteristic(characteristic)
            }

        if (result != BluetoothGatt.GATT_SUCCESS) {

            android.util.Log.e(
                "DeskBuddyBLE",
                "BLE write failed: $result"
            )

        } else {

            android.util.Log.d(
                "DeskBuddyBLE",
                "BLE write started"
            )
        }
    }

    private val gattCallback =
        object : BluetoothGattCallback() {

            override fun onConnectionStateChange(
                gatt: BluetoothGatt,
                status: Int,
                newState: Int
            ) {

                handler.post {

                    if (
                        status ==
                        BluetoothGatt.GATT_SUCCESS &&
                        newState ==
                        android.bluetooth.BluetoothProfile.STATE_CONNECTED
                    ) {

                        android.util.Log.d(
                            "DeskBuddyBLE",
                            "ESP32 connected"
                        )

                        connecting = false
                        connected = true

                        bluetoothGatt = gatt

                        if (
                            hasBluetoothPermission(
                                applicationContext
                            )
                        ) {
                            gatt.discoverServices()
                        }

                    } else {

                        android.util.Log.d(
                            "DeskBuddyBLE",
                            "ESP32 disconnected"
                        )

                        connected = false
                        connecting = false

                        notificationCharacteristic = null

                        try {
                            if (
                                hasBluetoothPermission(
                                    applicationContext
                                )
                            ) {
                                gatt.close()
                            }
                        } catch (_: Exception) {
                        }

                        bluetoothGatt = null

                        if (!messageQueue.isEmpty()) {
                            handler.postDelayed(
                                {
                                    connect()
                                },
                                2000
                            )
                        }
                    }
                }
            }

            override fun onServicesDiscovered(
                gatt: BluetoothGatt,
                status: Int
            ) {

                if (
                    status !=
                    BluetoothGatt.GATT_SUCCESS
                ) {

                    android.util.Log.e(
                        "DeskBuddyBLE",
                        "Service discovery failed: $status"
                    )

                    return
                }

                val service =
                    gatt.getService(
                        SERVICE_UUID
                    )

                if (service == null) {

                    android.util.Log.e(
                        "DeskBuddyBLE",
                        "Desk Buddy service not found"
                    )

                    return
                }

                notificationCharacteristic =
                    service.getCharacteristic(
                        CHARACTERISTIC_UUID
                    )

                if (
                    notificationCharacteristic == null
                ) {

                    android.util.Log.e(
                        "DeskBuddyBLE",
                        "Notification characteristic not found"
                    )

                    return
                }

                android.util.Log.d(
                    "DeskBuddyBLE",
                    "Desk Buddy BLE service ready"
                )

                handler.post {
                    processQueue()
                }
            }

            override fun onCharacteristicWrite(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
            ) {

                if (
                    status ==
                    BluetoothGatt.GATT_SUCCESS
                ) {

                    android.util.Log.d(
                        "DeskBuddyBLE",
                        "Notification delivered to ESP32"
                    )

                    messageQueue.poll()

                    handler.post {
                        processQueue()
                    }

                } else {

                    android.util.Log.e(
                        "DeskBuddyBLE",
                        "Characteristic write failed: $status"
                    )
                }
            }
        }

    private fun hasBluetoothPermission(
        context: Context?
    ): Boolean {

        if (context == null) {
            return false
        }

        return if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.S
        ) {

            context.checkSelfPermission(
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED

        } else {
            true
        }
    }
}