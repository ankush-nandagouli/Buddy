
package com.example.deskbuddy

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import java.nio.charset.StandardCharsets
import java.util.ArrayDeque
import java.util.UUID

object DeskBuddyBleManager {

    private const val TAG =
        "DeskBuddyBLE"

    private const val PREFS =
        "deskbuddy"

    private const val ESP32_ADDRESS =
        "esp32_address"

    private val SERVICE_UUID =
        UUID.fromString(
            "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
        )

    private val CHARACTERISTIC_UUID =
        UUID.fromString(
            "beb5483e-36e1-4688-b7f5-ea07361b26a8"
        )

    private var context:
        Context? = null

    private var bluetoothGatt:
        BluetoothGatt? = null

    private var targetCharacteristic:
        BluetoothGattCharacteristic? = null

    private var connecting =
        false

    private var writing =
        false

    /*
     * Notification queue.
     *
     * If a notification arrives while BLE is
     * connecting, it waits here.
     */
    private val queue =
        ArrayDeque<String>()

    private val handler =
        Handler(
            Looper.getMainLooper()
        )

    // ============================================================
    // Initialize
    // ============================================================

    fun initialize(
        ctx: Context
    ) {

        context =
            ctx.applicationContext

        Log.d(
            TAG,
            "BLE manager initialized"
        )
    }

    // ============================================================
    // Save ESP32 address
    // ============================================================

    fun setDeviceAddress(
        address: String
    ) {

        val ctx =
            context
                ?: return

        ctx.getSharedPreferences(
            PREFS,
            Context.MODE_PRIVATE
        )
            .edit()
            .putString(
                ESP32_ADDRESS,
                address
            )
            .apply()

        Log.d(
            TAG,
            "Saved ESP32 address: $address"
        )

        /*
         * Reconnect using the new address.
         */
        disconnect()

        connect()
    }

    // ============================================================
    // Get ESP32 address
    // ============================================================

    private fun getDeviceAddress():
        String? {

        val ctx =
            context
                ?: return null

        return ctx
            .getSharedPreferences(
                PREFS,
                Context.MODE_PRIVATE
            )
            .getString(
                ESP32_ADDRESS,
                null
            )
    }

    // ============================================================
    // Check permissions
    // ============================================================

    private fun hasBluetoothPermission():
        Boolean {

        val ctx =
            context
                ?: return false

        /*
         * Android 12+.
         */
        if (
            android.os.Build.VERSION.SDK_INT >=
            android.os.Build.VERSION_CODES.S
        ) {

            return ContextCompat.checkSelfPermission(
                ctx,
                Manifest.permission.BLUETOOTH_CONNECT
            ) ==
                PackageManager.PERMISSION_GRANTED
        }

        return true
    }

    // ============================================================
    // Connect
    // ============================================================

    @SuppressLint("MissingPermission")
    fun connect() {

        if (!hasBluetoothPermission()) {

            Log.e(
                TAG,
                "BLUETOOTH_CONNECT permission missing"
            )

            return
        }

        val ctx =
            context
                ?: return

        val address =
            getDeviceAddress()

        if (
            address.isNullOrBlank()
        ) {

            Log.d(
                TAG,
                "No ESP32 address configured"
            )

            return
        }

        /*
         * Already connected.
         */
        if (
            bluetoothGatt != null &&
            targetCharacteristic != null
        ) {

            Log.d(
                TAG,
                "ESP32 already connected"
            )

            flushQueue()

            return
        }

        /*
         * Already connecting.
         */
        if (connecting) {
            return
        }

        val adapter =
            BluetoothAdapter
                .getDefaultAdapter()

        if (
            adapter == null ||
            !adapter.isEnabled
        ) {

            Log.e(
                TAG,
                "Bluetooth unavailable or disabled"
            )

            return
        }

        val device =
            try {

                adapter.getRemoteDevice(
                    address
                )

            } catch (e: Exception) {

                Log.e(
                    TAG,
                    "Invalid ESP32 address: $address",
                    e
                )

                return
            }

        connecting =
            true

        Log.d(
            TAG,
            "Connecting to ESP32: $address"
        )

        bluetoothGatt =
            device.connectGatt(
                ctx,
                false,
                gattCallback,
                BluetoothDevice.TRANSPORT_LE
            )
    }

    // ============================================================
    // Disconnect
    // ============================================================

    @SuppressLint("MissingPermission")
    fun disconnect() {

        try {

            bluetoothGatt?.disconnect()

            bluetoothGatt?.close()

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Disconnect error",
                e
            )
        }

        bluetoothGatt =
            null

        targetCharacteristic =
            null

        connecting =
            false

        writing =
            false
    }

    // ============================================================
    // Send notification
    // ============================================================

    fun sendNotification(
        message: String
    ) {

        if (
            message.isBlank()
        ) {
            return
        }

        synchronized(queue) {

            /*
             * Prevent unbounded queue growth.
             */
            if (queue.size >= 20) {

                queue.removeFirst()

                Log.w(
                    TAG,
                    "Queue full; removed oldest notification"
                )
            }

            queue.addLast(
                message
            )
        }

        Log.d(
            TAG,
            "Queued notification: $message"
        )

        if (
            targetCharacteristic == null
        ) {

            connect()

        } else {

            flushQueue()
        }
    }

    // ============================================================
    // Write queue
    // ============================================================

    @SuppressLint("MissingPermission")
    private fun flushQueue() {

        if (writing) {
            return
        }

        val gatt =
            bluetoothGatt
                ?: return

        val characteristic =
            targetCharacteristic
                ?: return

        val message =
            synchronized(queue) {

                if (
                    queue.isEmpty()
                ) {

                    null

                } else {

                    queue.removeFirst()
                }
            }
                ?: return

        /*
         * Convert to UTF-8.
         */
        val bytes =
            message.toByteArray(
                StandardCharsets.UTF_8
            )

        /*
         * ESP32's current implementation
         * works with the normal BLE ATT payload.
         *
         * Default ATT MTU = 23
         * Payload = 20 bytes.
         *
         * We will keep this safe initially.
         */
        val maxPayload =
            20

        val data =
            if (
                bytes.size > maxPayload
            ) {

                Log.w(
                    TAG,
                    "Message too long; truncating"
                )

                bytes.copyOf(
                    maxPayload
                )

            } else {

                bytes
            }

        writing =
            true

        try {

            characteristic.writeType =
                BluetoothGattCharacteristic
                    .WRITE_TYPE_DEFAULT

            characteristic.value =
                data

            val started =
                gatt.writeCharacteristic(
                    characteristic
                )

            Log.d(
                TAG,
                "BLE write started: $started"
            )

            if (!started) {

                writing =
                    false

                synchronized(queue) {

                    queue.addFirst(
                        message
                    )
                }

                /*
                 * Retry.
                 */
                handler.postDelayed(
                    {
                        flushQueue()
                    },
                    500
                )
            }

        } catch (e: Exception) {

            writing =
                false

            synchronized(queue) {

                queue.addFirst(
                    message
                )
            }

            Log.e(
                TAG,
                "BLE write exception",
                e
            )

            handler.postDelayed(
                {
                    flushQueue()
                },
                1000
            )
        }
    }

    // ============================================================
    // GATT callbacks
    // ============================================================

    private val gattCallback =
        object : BluetoothGattCallback() {

            // ====================================================
            // Connection state
            // ====================================================

            @SuppressLint("MissingPermission")
            override fun onConnectionStateChange(
                gatt: BluetoothGatt,
                status: Int,
                newState: Int
            ) {

                Log.d(
                    TAG,
                    "Connection state: "
                        + "$newState status=$status"
                )

                connecting =
                    false

                if (
                    newState ==
                    BluetoothProfile.STATE_CONNECTED
                ) {

                    Log.d(
                        TAG,
                        "================================"
                    )

                    Log.d(
                        TAG,
                        "ESP32 CONNECTED"
                    )

                    Log.d(
                        TAG,
                        "================================"
                    )

                    bluetoothGatt =
                        gatt

                    gatt.discoverServices()

                } else if (
                    newState ==
                    BluetoothProfile.STATE_DISCONNECTED
                ) {

                    Log.w(
                        TAG,
                        "ESP32 DISCONNECTED"
                    )

                    targetCharacteristic =
                        null

                    writing =
                        false

                    try {
                        gatt.close()
                    } catch (_) {
                    }

                    bluetoothGatt =
                        null

                    /*
                     * Automatically reconnect.
                     */
                    handler.postDelayed(
                        {
                            connect()
                        },
                        3000
                    )
                }
            }

            // ====================================================
            // Services discovered
            // ====================================================

            override fun onServicesDiscovered(
                gatt: BluetoothGatt,
                status: Int
            ) {

                if (
                    status !=
                    BluetoothGatt.GATT_SUCCESS
                ) {

                    Log.e(
                        TAG,
                        "Service discovery failed: $status"
                    )

                    return
                }

                Log.d(
                    TAG,
                    "Services discovered"
                )

                val service =
                    gatt.getService(
                        SERVICE_UUID
                    )

                if (
                    service == null
                ) {

                    Log.e(
                        TAG,
                        "❌ Service UUID not found"
                    )

                    Log.e(
                        TAG,
                        SERVICE_UUID.toString()
                    )

                    return
                }

                Log.d(
                    TAG,
                    "✅ Service found"
                )

                targetCharacteristic =
                    service.getCharacteristic(
                        CHARACTERISTIC_UUID
                    )

                if (
                    targetCharacteristic == null
                ) {

                    Log.e(
                        TAG,
                        "❌ Characteristic not found"
                    )

                    Log.e(
                        TAG,
                        CHARACTERISTIC_UUID.toString()
                    )

                    return
                }

                Log.d(
                    TAG,
                    "================================"
                )

                Log.d(
                    TAG,
                    "ESP32 CHARACTERISTIC READY"
                )

                Log.d(
                    TAG,
                    "================================"
                )

                /*
                 * Send any waiting notifications.
                 */
                flushQueue()
            }

            // ====================================================
            // Characteristic written
            // ====================================================

            override fun onCharacteristicWrite(
                gatt: BluetoothGatt,
                characteristic:
                    BluetoothGattCharacteristic,
                status: Int
            ) {

                writing =
                    false

                Log.d(
                    TAG,
                    "Characteristic write status: $status"
                )

                if (
                    status ==
                    BluetoothGatt.GATT_SUCCESS
                ) {

                    Log.d(
                        TAG,
                        "✅ Notification sent to ESP32"
                    )

                    /*
                     * Send next queued notification.
                     */
                    flushQueue()

                } else {

                    Log.e(
                        TAG,
                        "❌ BLE write failed"
                    )

                    /*
                     * Retry the queue.
                     */
                    handler.postDelayed(
                        {
                            flushQueue()
                        },
                        500
                    )
                }
            }
        }
}
