package com.example.deskbuddy

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Bundle
import android.text.TextUtils
import java.util.Locale

class DeskBuddyNotificationService : NotificationListenerService() {

    companion object {

        private const val TAG = "DeskBuddyNotification"

        /*
         * Applications we want to mirror.
         *
         * Add/remove packages here as required.
         */
        private val ALLOWED_PACKAGES = setOf(
            "com.whatsapp",
            "com.whatsapp.w4b",
            "org.telegram.messenger",
            "com.google.android.gm",
            "com.microsoft.teams",
            "com.instagram.android",
            "com.facebook.orca",
            "com.android.messaging"
        )

        private const val MAX_MESSAGE_LENGTH = 180

        private var lastNotificationKey: String? = null
        private var lastNotificationTime: Long = 0L

        private const val DUPLICATE_WINDOW_MS = 2000L
    }

    override fun onListenerConnected() {
        super.onListenerConnected()

        android.util.Log.d(
            TAG,
            "Notification listener connected"
        )
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()

        android.util.Log.d(
            TAG,
            "Notification listener disconnected"
        )
    }

    override fun onNotificationPosted(
        sbn: StatusBarNotification
    ) {
        try {
            processNotification(sbn)
        } catch (e: Exception) {
            android.util.Log.e(
                TAG,
                "Error processing notification",
                e
            )
        }
    }

    private fun processNotification(
        sbn: StatusBarNotification
    ) {

        val packageName = sbn.packageName

        /*
         * Ignore our own application.
         */
        if (packageName == applicationContext.packageName) {
            return
        }

        /*
         * Ignore applications that aren't selected.
         */
        if (!ALLOWED_PACKAGES.contains(packageName)) {
            return
        }

        val notification = sbn.notification ?: return

        /*
         * Ignore group summaries.
         */
        if ((notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) {
            return
        }

        /*
         * Ignore notifications without useful content.
         */
        if ((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0) {
            return
        }

        val key = sbn.key

        if (isDuplicate(key)) {
            return
        }

        val extras = notification.extras ?: return

        val applicationName = getApplicationLabel(packageName)

        val conversationTitle =
            getCharSequence(
                extras,
                Notification.EXTRA_CONVERSATION_TITLE
            )

        val title =
            getCharSequence(
                extras,
                Notification.EXTRA_TITLE
            )

        /*
         * First try MessagingStyle.
         */
        val messagingText =
            extractMessagingStyle(extras)

        /*
         * Then fall back to normal notification text.
         */
        val body =
            if (!messagingText.isNullOrBlank()) {
                messagingText
            } else {
                extractNormalText(extras)
            }

        if (body.isNullOrBlank() && title.isNullOrBlank()) {
            return
        }

        val senderOrTitle =
            when {
                !conversationTitle.isNullOrBlank() ->
                    conversationTitle

                !title.isNullOrBlank() ->
                    title

                else ->
                    applicationName
            }

        val finalMessage =
            buildDisplayMessage(
                applicationName = applicationName,
                title = senderOrTitle,
                body = body ?: ""
            )

        if (finalMessage.isBlank()) {
            return
        }

        android.util.Log.d(
            TAG,
            "Forwarding notification: $finalMessage"
        )

        DeskBuddyBleManager.sendNotification(
            applicationContext,
            finalMessage
        )
    }

    private fun extractMessagingStyle(
        extras: Bundle
    ): String? {

        if (!extras.containsKey(Notification.EXTRA_MESSAGES)) {
            return null
        }

        return try {

            val messages =
                Notification.MessagingStyle.Message
                    .getMessagesFromBundleArray(
                        extras.getParcelableArray(
                            Notification.EXTRA_MESSAGES
                        )
                    )

            if (messages.isNullOrEmpty()) {
                return null
            }

            /*
             * The last message is normally the newest message.
             */
            val latestMessage =
                messages.lastOrNull()
                    ?: return null

            latestMessage.text?.toString()?.trim()

        } catch (e: Exception) {

            android.util.Log.e(
                TAG,
                "MessagingStyle extraction failed",
                e
            )

            null
        }
    }

    private fun extractNormalText(
        extras: Bundle
    ): String? {

        /*
         * Standard notification text.
         */
        val text =
            getCharSequence(
                extras,
                Notification.EXTRA_TEXT
            )

        if (!text.isNullOrBlank()) {
            return text
        }

        /*
         * Expanded/big text.
         */
        val bigText =
            getCharSequence(
                extras,
                Notification.EXTRA_BIG_TEXT
            )

        if (!bigText.isNullOrBlank()) {
            return bigText
        }

        /*
         * Some applications provide multiple text lines.
         */
        val lines =
            extras.getCharSequenceArray(
                Notification.EXTRA_TEXT_LINES
            )

        if (!lines.isNullOrEmpty()) {

            return lines
                .filterNotNull()
                .joinToString(" ")
                .trim()
        }

        return null
    }

    private fun getCharSequence(
        extras: Bundle,
        key: String
    ): String? {

        return try {
            extras.getCharSequence(key)
                ?.toString()
                ?.trim()
        } catch (e: Exception) {
            null
        }
    }

    private fun buildDisplayMessage(
        applicationName: String,
        title: String,
        body: String
    ): String {

        val result =
            if (body.isBlank()) {
                "$applicationName: $title"
            } else {
                "$title: $body"
            }

        return result
            .replace("\n", " ")
            .replace("\r", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(MAX_MESSAGE_LENGTH)
    }

    private fun getApplicationLabel(
        packageName: String
    ): String {

        return try {

            val packageManager =
                applicationContext.packageManager

            val applicationInfo =
                packageManager.getApplicationInfo(
                    packageName,
                    0
                )

            packageManager
                .getApplicationLabel(applicationInfo)
                .toString()

        } catch (e: Exception) {

            packageName
        }
    }

    private fun isDuplicate(
        key: String
    ): Boolean {

        val now = System.currentTimeMillis()

        val duplicate =
            key == lastNotificationKey &&
            now - lastNotificationTime <
            DUPLICATE_WINDOW_MS

        lastNotificationKey = key
        lastNotificationTime = now

        return duplicate
    }
}