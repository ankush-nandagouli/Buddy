
package com.example.deskbuddy

import android.os.SystemClock

object DeskBuddyNotificationDeduplicator {

    private var lastPayload =
        ""

    private var lastTime =
        0L

    private const val WINDOW =
        2000L

    @Synchronized
    fun isDuplicate(
        payload: String
    ): Boolean {

        val now =
            SystemClock.elapsedRealtime()

        val duplicate =
            payload == lastPayload &&
            now - lastTime < WINDOW

        if (!duplicate) {

            lastPayload =
                payload

            lastTime =
                now
        }

        return duplicate
    }
}
