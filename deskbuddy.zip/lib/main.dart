import 'dart:async';
import 'dart:convert';
import 'dart:isolate';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_notification_listener/flutter_notification_listener.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String SERVICE_UUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
const String CHARACTERISTIC_UUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8";

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: DeskBuddyApp(),
  ));
}

class DeskBuddyApp extends StatefulWidget {
  const DeskBuddyApp({super.key});

  @override
  State<DeskBuddyApp> createState() => _DeskBuddyAppState();
}

class _DeskBuddyAppState extends State<DeskBuddyApp> {
  BluetoothDevice? connectedDevice;
  BluetoothCharacteristic? targetCharacteristic;
  List<ScanResult> scanResults = [];
  bool isScanning = false;
  int currentMtu = 23;
  String _lastProcessedPayload = "";
  DateTime _lastProcessedTime = DateTime.now();

  final Map<String, String> availableApps = {
    'com.whatsapp': 'WhatsApp',
    'com.whatsapp.w4b': 'WhatsApp Business',
    'com.google.android.apps.messaging': 'Google Messages',
    'com.instagram.android': 'Instagram',
    'com.slack': 'Slack',
    'com.android.email': 'Email',
  };

  Set<String> selectedPackages = {'com.whatsapp', 'com.whatsapp.w4b'};
  final ReceivePort _port = ReceivePort();

  @override
  void initState() {
    super.initState();
    _loadSelectedApps();
    _initNotificationListener();
  }

  Future<void> _loadSelectedApps() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('selected_packages');
    if (saved != null) {
      setState(() {
        selectedPackages = saved.toSet();
      });
    }
  }

  Future<void> _toggleAppSelection(String pkg, bool selected) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (selected) {
        selectedPackages.add(pkg);
      } else {
        selectedPackages.remove(pkg);
      }
    });
    await prefs.setStringList('selected_packages', selectedPackages.toList());
  }

  // --- Background Notification Listener ---
  void _initNotificationListener() async {
    IsolateNameServer.removePortNameMapping("_desk_buddy_port_");
    IsolateNameServer.registerPortWithName(_port.sendPort, "_desk_buddy_port_");

    _port.listen((message) {
      _handleIncomingNotification(message as Map<String, dynamic>);
    });

    bool? hasPermission = await NotificationsListener.hasPermission;
    if (hasPermission != true) {
      debugPrint(">> Notification Access NOT granted. Opening settings...");
      await NotificationsListener.openPermissionSettings();
    }

    await NotificationsListener.initialize(
        callbackHandle: _notificationCallback);

    bool? isRunning = await NotificationsListener.isRunning;
    if (isRunning != true) {
      await NotificationsListener.startService(
        title: "Desk Buddy Active",
        description: "Listening and routing notifications to your Desk Buddy",
      );
    }
  }

  // Pure background isolate execution entrypoint
  @pragma('vm:entry-point')
  static void _notificationCallback(NotificationEvent evt) {
    final SendPort? sendPort =
        IsolateNameServer.lookupPortByName("_desk_buddy_port_");
    if (sendPort == null || evt.packageName == null) return;

    // 1. Gather all potential payload fields across Android OS versions
    String title = (evt.title ?? '').trim();
    String body = (evt.message ?? evt.text ?? '').trim();

    // 2. Ignore empty or system dismiss events
    if (title.isEmpty && body.isEmpty) return;

    // 3. WhatsApp Background Filter
    String lowerBody = body.toLowerCase();
    String lowerTitle = title.toLowerCase();

    if (lowerBody.contains("checking for new messages") ||
        lowerBody.contains("whatsapp web is currently active") ||
        lowerBody.contains("backup in progress") ||
        lowerTitle == "whatsapp") {
      if (lowerBody.contains("messages") && !lowerBody.contains(":")) {
        // Drop generic "X new messages" summary notifications
        return;
      }
    }

    sendPort.send({
      'package': evt.packageName,
      'title': title,
      'text': body,
    });
  }

  void _handleIncomingNotification(Map<String, dynamic> data) {
    final String pkg = data['package'] ?? '';

    if (selectedPackages.contains(pkg)) {
      String title = (data['title'] as String).trim();
      String text = (data['text'] as String).trim();

      String payload;
      if (title.isNotEmpty && text.isNotEmpty) {
        payload = "$title: $text";
      } else {
        payload = text.isNotEmpty ? text : title;
      }

      // De-bounce: prevent WhatsApp multi-event flooding within 2 seconds
      final now = DateTime.now();
      if (payload == _lastProcessedPayload &&
          now.difference(_lastProcessedTime).inSeconds < 2) {
        return;
      }

      _lastProcessedPayload = payload;
      _lastProcessedTime = now;

      debugPrint(">> FORWARDING NOTIFICATION: $payload");
      _sendPayloadToESP32(payload);
    }
  }

  // --- BLE Connection Logic ---
  Future<void> _requestPermissionsAndScan() async {
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
      Permission.ignoreBatteryOptimizations,
    ].request();

    setState(() {
      scanResults.clear();
      isScanning = true;
    });

    FlutterBluePlus.scanResults.listen((results) {
      setState(() {
        scanResults = results;
      });
    });

    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 5));
    setState(() => isScanning = false);
  }

  Future<void> _connectToDevice(BluetoothDevice device) async {
    await device.connect(autoConnect: true);
    setState(() => connectedDevice = device);

    // Track disconnection
    device.connectionState.listen((state) {
      if (state == BluetoothConnectionState.disconnected) {
        setState(() {
          connectedDevice = null;
          targetCharacteristic = null;
        });
      }
    });

    try {
      currentMtu = await device.requestMtu(512);
      debugPrint(">> Negotiated MTU: $currentMtu");
    } catch (e) {
      debugPrint("MTU request error: $e");
    }

    await Future.delayed(const Duration(milliseconds: 500));

    List<BluetoothService> services = await device.discoverServices();
    for (var s in services) {
      if (s.uuid.toString().toLowerCase() == SERVICE_UUID.toLowerCase()) {
        for (var c in s.characteristics) {
          if (c.uuid.toString().toLowerCase() ==
              CHARACTERISTIC_UUID.toLowerCase()) {
            setState(() => targetCharacteristic = c);
            debugPrint(">> BLE Characteristic ready for data writes");
            break;
          }
        }
      }
    }
  }

  Future<void> _sendPayloadToESP32(String text) async {
    if (targetCharacteristic != null && connectedDevice != null) {
      final int maxPayloadBytes = (connectedDevice?.mtuNow ?? currentMtu) - 3;
      List<int> encodedBytes = utf8.encode(text);

      if (encodedBytes.length > maxPayloadBytes) {
        encodedBytes = encodedBytes.sublist(0, maxPayloadBytes);
      }

      await targetCharacteristic!.write(encodedBytes, withoutResponse: false);
      debugPrint(">> Dispatched to ESP32: $text");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Desk Buddy BLE Manager")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Connection Card
          Card(
            elevation: 2,
            child: ListTile(
              title: Text(connectedDevice != null
                  ? "Connected: ${connectedDevice!.remoteId.str}"
                  : "No Device Connected"),
              subtitle: Text(targetCharacteristic != null
                  ? "Service Active | MTU: ${connectedDevice?.mtuNow ?? currentMtu} bytes"
                  : "GATT Link Offline"),
              trailing: ElevatedButton(
                onPressed: isScanning ? null : _requestPermissionsAndScan,
                child: Text(isScanning ? "Scanning..." : "Scan BLE"),
              ),
            ),
          ),
          const SizedBox(height: 10),

          // Diagnostic Manual Button
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            icon: const Icon(Icons.send),
            label: const Text("SEND TEST NOTIFICATION"),
            onPressed: () => _sendPayloadToESP32("Ankush: Testing Desk Buddy!"),
          ),

          const Divider(height: 30),

          const Text("Detected Bluetooth Devices:",
              style: TextStyle(fontWeight: FontWeight.bold)),
          ...scanResults.map((r) => ListTile(
                title: Text(r.device.platformName.isNotEmpty
                    ? r.device.platformName
                    : "Unknown Device"),
                subtitle: Text(
                    "MAC: ${r.device.remoteId.str} | Signal: ${r.rssi} dBm"),
                trailing: ElevatedButton(
                  onPressed: () => _connectToDevice(r.device),
                  child: const Text("Connect"),
                ),
              )),

          const Divider(height: 30),

          const Text("Notification App Routing:",
              style: TextStyle(fontWeight: FontWeight.bold)),
          ...availableApps.entries.map((entry) {
            return CheckboxListTile(
              title: Text(entry.value),
              subtitle: Text(entry.key),
              value: selectedPackages.contains(entry.key),
              onChanged: (val) => _toggleAppSelection(entry.key, val ?? false),
            );
          }),
        ],
      ),
    );
  }
}
