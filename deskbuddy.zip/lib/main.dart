import 'dart:async';
import 'dart:convert';
import 'dart:isolate';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_notification_listener/flutter_notification_listener.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String SERVICE_UUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";

const String CHARACTERISTIC_UUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8";

const String PORT_NAME = "_desk_buddy_port_";

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DeskBuddyApp(),
    ),
  );
}

class DeskBuddyApp extends StatefulWidget {
  const DeskBuddyApp({super.key});

  @override
  State<DeskBuddyApp> createState() => _DeskBuddyAppState();
}

class _DeskBuddyAppState extends State<DeskBuddyApp>
    with WidgetsBindingObserver {
  // ============================================================
  // BLE
  // ============================================================

  BluetoothDevice? connectedDevice;
  BluetoothCharacteristic? targetCharacteristic;

  List<ScanResult> scanResults = [];

  bool isScanning = false;
  bool isConnecting = false;
  bool isNotificationAccessGranted = false;
  bool notificationServiceRunning = false;

  int currentMtu = 23;

  StreamSubscription<List<ScanResult>>? _scanSubscription;
  StreamSubscription<BluetoothConnectionState>? _connectionSubscription;

  // ============================================================
  // Notification Listener
  // ============================================================

  final ReceivePort _port = ReceivePort();

  StreamSubscription? _notificationPortSubscription;

  // ============================================================
  // Duplicate protection
  // ============================================================

  String _lastProcessedPayload = "";
  DateTime _lastProcessedTime = DateTime.fromMillisecondsSinceEpoch(0);

  // ============================================================
  // Supported Apps
  // ============================================================

  final Map<String, String> availableApps = {
    'com.whatsapp': 'WhatsApp',
    'com.whatsapp.w4b': 'WhatsApp Business',
    'com.google.android.apps.messaging': 'Google Messages',
    'com.instagram.android': 'Instagram',
    'com.slack': 'Slack',
    'com.android.email': 'Email',
    'com.google.android.gm': 'Gmail',
    'org.telegram.messenger': 'Telegram',
  };

  Set<String> selectedPackages = {
    'com.whatsapp',
    'com.whatsapp.w4b',
  };

  // ============================================================
  // Lifecycle
  // ============================================================

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addObserver(this);

    _loadSelectedApps();

    _setupNotificationPort();

    // Give Flutter a moment to initialize.
    Future.delayed(
      const Duration(milliseconds: 800),
      () {
        _initializeNotificationListener();
      },
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);

    _scanSubscription?.cancel();
    _connectionSubscription?.cancel();
    _notificationPortSubscription?.cancel();

    IsolateNameServer.removePortNameMapping(PORT_NAME);

    _port.close();

    super.dispose();
  }

  // ============================================================
  // Android lifecycle
  //
  // Important:
  // When we open Notification Access Settings, the user must
  // manually enable access and return to the app.
  //
  // We therefore check permission again when the app resumes.
  // ============================================================

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      debugPrint("📱 App resumed");

      Future.delayed(
        const Duration(milliseconds: 700),
        () {
          _checkNotificationPermissionAndStart();
        },
      );
    }
  }

  // ============================================================
  // Notification Port
  // ============================================================

  void _setupNotificationPort() {
    IsolateNameServer.removePortNameMapping(PORT_NAME);

    final bool registered = IsolateNameServer.registerPortWithName(
      _port.sendPort,
      PORT_NAME,
    );

    debugPrint(
      registered
          ? "✅ Notification SendPort registered"
          : "❌ Failed to register Notification SendPort",
    );

    _notificationPortSubscription = _port.listen(
      (dynamic message) {
        debugPrint(
          "📥 Message received from notification isolate: $message",
        );

        if (message is Map) {
          try {
            final data = Map<String, dynamic>.from(message);

            _handleIncomingNotification(data);
          } catch (e) {
            debugPrint(
              "❌ Error converting notification data: $e",
            );
          }
        }
      },
    );
  }

  // ============================================================
  // Load selected apps
  // ============================================================

  Future<void> _loadSelectedApps() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final saved = prefs.getStringList('selected_packages');

      if (saved != null) {
        if (!mounted) return;

        setState(() {
          selectedPackages = saved.toSet();
        });

        debugPrint(
          "📱 Loaded selected apps: $selectedPackages",
        );
      }
    } catch (e) {
      debugPrint(
        "❌ Failed to load selected apps: $e",
      );
    }
  }

  // ============================================================
  // Toggle app
  // ============================================================

  Future<void> _toggleAppSelection(
    String packageName,
    bool selected,
  ) async {
    final prefs = await SharedPreferences.getInstance();

    if (!mounted) return;

    setState(() {
      if (selected) {
        selectedPackages.add(packageName);
      } else {
        selectedPackages.remove(packageName);
      }
    });

    await prefs.setStringList(
      'selected_packages',
      selectedPackages.toList(),
    );

    debugPrint(
      selected ? "✅ Enabled app: $packageName" : "❌ Disabled app: $packageName",
    );
  }

  // ============================================================
  // Notification Listener Initialization
  // ============================================================

  Future<void> _initializeNotificationListener() async {
    debugPrint("");
    debugPrint("========================================");
    debugPrint("🔔 INITIALIZING NOTIFICATION LISTENER");
    debugPrint("========================================");

    await _checkNotificationPermissionAndStart();
  }

  // ============================================================
  // Check notification access
  // ============================================================

  Future<void> _checkNotificationPermissionAndStart() async {
    try {
      final bool? permission = await NotificationsListener.hasPermission;

      final bool granted = permission == true;

      debugPrint(
        "🔐 Notification Access Permission: $granted",
      );

      if (!mounted) return;

      setState(() {
        isNotificationAccessGranted = granted;
      });

      if (!granted) {
        debugPrint(
          "⚠️ Notification Access is NOT enabled.",
        );

        return;
      }

      debugPrint(
        "✅ Notification Access is enabled.",
      );

      await _startNotificationService();
    } catch (e, stack) {
      debugPrint(
        "❌ Notification permission check failed: $e",
      );

      debugPrint(stack.toString());
    }
  }

  // ============================================================
  // Open Notification Access Settings
  // ============================================================

  Future<void> _openNotificationSettings() async {
    try {
      debugPrint(
        "⚙️ Opening Android Notification Access settings...",
      );

      await NotificationsListener.openPermissionSettings();
    } catch (e) {
      debugPrint(
        "❌ Could not open notification settings: $e",
      );
    }
  }

  // ============================================================
  // Start Notification Service
  // ============================================================

  Future<void> _startNotificationService() async {
    try {
      debugPrint(
        "🔄 Initializing notification listener...",
      );

      await NotificationsListener.initialize(
        callbackHandle: _notificationCallback,
      );

      debugPrint(
        "✅ Notification listener initialized",
      );

      final bool? running = await NotificationsListener.isRunning;

      debugPrint(
        "🔄 Notification service running: $running",
      );

      if (running != true) {
        debugPrint(
          "🚀 Starting notification listener service...",
        );

        await NotificationsListener.startService(
          title: "Desk Buddy Active",
          description: "Listening and routing notifications to your Desk Buddy",
        );

        debugPrint(
          "✅ Notification listener service started",
        );
      }

      if (!mounted) return;

      setState(() {
        notificationServiceRunning = true;
      });
    } catch (e, stack) {
      debugPrint(
        "❌ Failed to start notification listener: $e",
      );

      debugPrint(stack.toString());

      if (!mounted) return;

      setState(() {
        notificationServiceRunning = false;
      });
    }
  }

  // ============================================================
  // Background notification callback
  //
  // MUST remain a top-level reachable entry point.
  // ============================================================

  @pragma('vm:entry-point')
  static void _notificationCallback(
    NotificationEvent evt,
  ) {
    debugPrint("");
    debugPrint("========================================");
    debugPrint("🔔 ANDROID NOTIFICATION RECEIVED");
    debugPrint("========================================");

    debugPrint(
      "Package: ${evt.packageName}",
    );

    debugPrint(
      "Title: ${evt.title}",
    );

    debugPrint(
      "Message: ${evt.message}",
    );

    debugPrint(
      "Text: ${evt.text}",
    );

    debugPrint("========================================");

    final SendPort? sendPort = IsolateNameServer.lookupPortByName(PORT_NAME);

    if (sendPort == null) {
      debugPrint(
        "❌ Notification SendPort not found",
      );

      return;
    }

    final String packageName = (evt.packageName ?? '').trim();

    final String title = (evt.title ?? '').trim();

    final String message = (evt.message ?? '').trim();

    final String text = (evt.text ?? '').trim();

    // Prefer message, then text.
    String body = message;

    if (body.isEmpty) {
      body = text;
    }

    // Ignore notifications with absolutely no usable content.
    if (packageName.isEmpty && title.isEmpty && body.isEmpty) {
      debugPrint(
        "⚠️ Empty notification ignored",
      );

      return;
    }

    sendPort.send({
      'package': packageName,
      'title': title,
      'text': body,
    });

    debugPrint(
      "📤 Notification sent to Flutter isolate",
    );
  }

  // ============================================================
  // Handle notification
  // ============================================================

  void _handleIncomingNotification(
    Map<String, dynamic> data,
  ) {
    final String packageName = (data['package'] ?? '').toString().trim();

    final String title = (data['title'] ?? '').toString().trim();

    final String text = (data['text'] ?? '').toString().trim();

    debugPrint("");
    debugPrint("========================================");
    debugPrint("📥 FLUTTER RECEIVED NOTIFICATION");
    debugPrint("Package : $packageName");
    debugPrint("Title   : $title");
    debugPrint("Text    : $text");
    debugPrint("========================================");

    // ------------------------------------------------------------
    // Check selected applications
    // ------------------------------------------------------------

    if (!selectedPackages.contains(packageName)) {
      debugPrint(
        "⚠️ App is not selected: $packageName",
      );

      return;
    }

    // ------------------------------------------------------------
    // Build display message
    // ------------------------------------------------------------

    String payload = "";

    if (title.isNotEmpty && text.isNotEmpty) {
      payload = "$title: $text";
    } else if (text.isNotEmpty) {
      payload = text;
    } else if (title.isNotEmpty) {
      payload = title;
    }

    payload = payload.trim();

    if (payload.isEmpty) {
      debugPrint(
        "⚠️ Notification contains no displayable text",
      );

      return;
    }

    // ------------------------------------------------------------
    // Duplicate protection
    // ------------------------------------------------------------

    final now = DateTime.now();

    final bool isDuplicate = payload == _lastProcessedPayload &&
        now.difference(_lastProcessedTime).inMilliseconds < 2000;

    if (isDuplicate) {
      debugPrint(
        "⚠️ Duplicate notification ignored",
      );

      return;
    }

    _lastProcessedPayload = payload;
    _lastProcessedTime = now;

    debugPrint(
      "📤 FORWARDING NOTIFICATION TO ESP32",
    );

    debugPrint(
      "Payload: $payload",
    );

    _sendPayloadToESP32(payload);
  }

  // ============================================================
  // Request BLE permissions and scan
  // ============================================================

  Future<void> _requestPermissionsAndScan() async {
    try {
      debugPrint(
        "🔐 Requesting Bluetooth permissions...",
      );

      await [
        Permission.bluetoothScan,
        Permission.bluetoothConnect,
        Permission.location,
      ].request();

      debugPrint(
        "🔍 Starting BLE scan...",
      );

      if (!mounted) return;

      setState(() {
        scanResults.clear();
        isScanning = true;
      });

      await _scanSubscription?.cancel();

      _scanSubscription = FlutterBluePlus.scanResults.listen(
        (results) {
          if (!mounted) return;

          setState(() {
            scanResults = results;
          });
        },
        onError: (error) {
          debugPrint(
            "❌ BLE scan error: $error",
          );
        },
      );

      await FlutterBluePlus.startScan(
        timeout: const Duration(seconds: 7),
      );

      debugPrint(
        "✅ BLE scan completed",
      );
    } catch (e) {
      debugPrint(
        "❌ BLE scan failed: $e",
      );
    } finally {
      if (mounted) {
        setState(() {
          isScanning = false;
        });
      }
    }
  }

  // ============================================================
  // Connect to ESP32
  // ============================================================

  Future<void> _connectToDevice(
    BluetoothDevice device,
  ) async {
    if (isConnecting) return;

    try {
      if (mounted) {
        setState(() {
          isConnecting = true;
        });
      }

      debugPrint(
        "🔵 Connecting to ${device.remoteId}...",
      );

      try {
        await device.connect(
          autoConnect: false,
        );
      } catch (e) {
        // FlutterBluePlus can report an already-connected device
        // as an error. Continue and check services.
        debugPrint(
          "ℹ️ Connect result: $e",
        );
      }

      if (!mounted) return;

      setState(() {
        connectedDevice = device;
      });

      await _connectionSubscription?.cancel();

      _connectionSubscription = device.connectionState.listen(
        (state) {
          debugPrint(
            "🔵 BLE connection state: $state",
          );

          if (state == BluetoothConnectionState.disconnected) {
            debugPrint(
              "❌ ESP32 disconnected",
            );

            if (!mounted) return;

            setState(() {
              connectedDevice = null;
              targetCharacteristic = null;
              currentMtu = 23;
            });
          }
        },
      );

      // ----------------------------------------------------------
      // MTU
      // ----------------------------------------------------------

      try {
        currentMtu = await device.requestMtu(512);

        debugPrint(
          "📏 Negotiated MTU: $currentMtu",
        );
      } catch (e) {
        debugPrint(
          "ℹ️ MTU request failed/defaulted: $e",
        );
      }

      await Future.delayed(
        const Duration(milliseconds: 500),
      );

      // ----------------------------------------------------------
      // Discover services
      // ----------------------------------------------------------

      debugPrint(
        "🔎 Discovering BLE services...",
      );

      final services = await device.discoverServices();

      bool foundCharacteristic = false;

      for (final service in services) {
        debugPrint(
          "Service: ${service.uuid}",
        );

        if (service.uuid.toString().toLowerCase() !=
            SERVICE_UUID.toLowerCase()) {
          continue;
        }

        for (final characteristic in service.characteristics) {
          debugPrint(
            "Characteristic: ${characteristic.uuid}",
          );

          if (characteristic.uuid.toString().toLowerCase() ==
              CHARACTERISTIC_UUID.toLowerCase()) {
            if (!mounted) return;

            setState(() {
              targetCharacteristic = characteristic;
            });

            foundCharacteristic = true;

            debugPrint(
              "✅ BLE characteristic ready",
            );

            break;
          }
        }
      }

      if (!foundCharacteristic) {
        debugPrint(
          "❌ Target BLE characteristic NOT found",
        );
      }
    } catch (e, stack) {
      debugPrint(
        "❌ ESP32 connection failed: $e",
      );

      debugPrint(stack.toString());
    } finally {
      if (mounted) {
        setState(() {
          isConnecting = false;
        });
      }
    }
  }

  // ============================================================
  // Send data to ESP32
  // ============================================================

  Future<void> _sendPayloadToESP32(
    String text,
  ) async {
    final characteristic = targetCharacteristic;

    final device = connectedDevice;

    if (characteristic == null || device == null) {
      debugPrint(
        "❌ Cannot send notification: ESP32 not connected",
      );

      return;
    }

    try {
      final List<int> encodedBytes = utf8.encode(text);

      final int mtu = device.mtuNow > 0 ? device.mtuNow : currentMtu;

      // BLE ATT payload normally allows MTU - 3.
      final int maxPayloadBytes = mtu > 3 ? mtu - 3 : 20;

      // ----------------------------------------------------------
      // For now keep notifications within a single BLE packet.
      // We will add chunking later if required.
      // ----------------------------------------------------------

      List<int> payloadBytes = List<int>.from(encodedBytes);

      if (payloadBytes.length > maxPayloadBytes) {
        debugPrint(
          "⚠️ Notification too long: "
          "${payloadBytes.length} bytes. "
          "Maximum: $maxPayloadBytes bytes.",
        );

        payloadBytes = payloadBytes.sublist(
          0,
          maxPayloadBytes,
        );

        // Avoid cutting UTF-8 incorrectly.
        while (payloadBytes.isNotEmpty) {
          try {
            utf8.decode(payloadBytes);
            break;
          } catch (_) {
            payloadBytes.removeLast();
          }
        }
      }

      final String finalText = utf8.decode(
        payloadBytes,
        allowMalformed: true,
      );

      debugPrint(
        "📡 BLE SEND: $finalText",
      );

      await characteristic.write(
        payloadBytes,
        withoutResponse: false,
      );

      debugPrint(
        "✅ Notification dispatched to ESP32",
      );
    } catch (e, stack) {
      debugPrint(
        "❌ BLE write failed: $e",
      );

      debugPrint(stack.toString());
    }
  }

  // ============================================================
  // Manual test
  // ============================================================

  Future<void> _sendTestNotification() async {
    await _sendPayloadToESP32(
      "Ankush: Testing Desk Buddy!",
    );
  }

  // ============================================================
  // UI
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Desk Buddy BLE Manager",
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ======================================================
          // Notification status
          // ======================================================

          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Notification Listener",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(
                        isNotificationAccessGranted
                            ? Icons.check_circle
                            : Icons.error,
                        color: isNotificationAccessGranted
                            ? Colors.green
                            : Colors.red,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          isNotificationAccessGranted
                              ? "Notification Access Granted"
                              : "Notification Access NOT Granted",
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(
                        notificationServiceRunning
                            ? Icons.play_circle
                            : Icons.stop_circle,
                        color: notificationServiceRunning
                            ? Colors.green
                            : Colors.orange,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          notificationServiceRunning
                              ? "Listener Service Running"
                              : "Listener Service Not Running",
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _openNotificationSettings,
                          icon: const Icon(
                            Icons.settings,
                          ),
                          label: const Text(
                            "Notification Access",
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _checkNotificationPermissionAndStart,
                          icon: const Icon(
                            Icons.refresh,
                          ),
                          label: const Text(
                            "Check",
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          // ======================================================
          // BLE Connection
          // ======================================================

          Card(
            elevation: 2,
            child: ListTile(
              title: Text(
                connectedDevice != null
                    ? "Connected: "
                        "${connectedDevice!.remoteId.str}"
                    : "No Device Connected",
              ),
              subtitle: Text(
                targetCharacteristic != null
                    ? "GATT Active | MTU: "
                        "${connectedDevice?.mtuNow ?? currentMtu}"
                    : "GATT Link Offline",
              ),
              trailing: ElevatedButton(
                onPressed: isScanning ? null : _requestPermissionsAndScan,
                child: Text(
                  isScanning ? "Scanning..." : "Scan BLE",
                ),
              ),
            ),
          ),

          const SizedBox(height: 10),

          // ======================================================
          // Test button
          // ======================================================

          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                vertical: 14,
              ),
            ),
            icon: const Icon(Icons.send),
            label: const Text(
              "SEND TEST NOTIFICATION",
            ),
            onPressed:
                targetCharacteristic != null ? _sendTestNotification : null,
          ),

          const Divider(height: 30),

          // ======================================================
          // BLE devices
          // ======================================================

          const Text(
            "Detected Bluetooth Devices:",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),

          const SizedBox(height: 8),

          if (scanResults.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text(
                "No BLE devices found. Tap Scan BLE.",
              ),
            ),

          ...scanResults.map(
            (result) {
              final String name = result.device.platformName;

              return ListTile(
                leading: const Icon(
                  Icons.bluetooth,
                ),
                title: Text(
                  name.isNotEmpty ? name : "Unknown Device",
                ),
                subtitle: Text(
                  "ID: ${result.device.remoteId.str}\n"
                  "Signal: ${result.rssi} dBm",
                ),
                isThreeLine: true,
                trailing: ElevatedButton(
                  onPressed: isConnecting
                      ? null
                      : () => _connectToDevice(
                            result.device,
                          ),
                  child: Text(
                    isConnecting ? "..." : "Connect",
                  ),
                ),
              );
            },
          ),

          const Divider(height: 30),

          // ======================================================
          // App routing
          // ======================================================

          const Text(
            "Notification App Routing:",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),

          const SizedBox(height: 8),

          ...availableApps.entries.map(
            (entry) {
              return CheckboxListTile(
                title: Text(entry.value),
                subtitle: Text(entry.key),
                value: selectedPackages.contains(
                  entry.key,
                ),
                onChanged: (value) {
                  _toggleAppSelection(
                    entry.key,
                    value ?? false,
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
