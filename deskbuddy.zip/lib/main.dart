import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String serviceUuid = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";

const String characteristicUuid = "beb5483e-36e1-4688-b7f5-ea07361b26a8";

const MethodChannel nativeChannel = MethodChannel('deskbuddy/native');

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DeskBuddyApp(),
    ),
  );
}

class DeskBuddyApp extends StatefulWidget {
  const DeskBuddyApp({super.key});

  @override
  State<DeskBuddyApp> createState() => _DeskBuddyAppState();
}

class _DeskBuddyAppState extends State<DeskBuddyApp>
    with WidgetsBindingObserver {
  // ============================================================
  // BLE
  // ============================================================

  BluetoothDevice? connectedDevice;

  BluetoothCharacteristic? targetCharacteristic;

  List<ScanResult> scanResults = [];

  StreamSubscription<List<ScanResult>>? scanSubscription;

  StreamSubscription<BluetoothConnectionState>? connectionSubscription;

  bool isScanning = false;

  bool isConnecting = false;

  bool notificationAccessGranted = false;

  String esp32Address = "";

  int currentMtu = 23;

  // ============================================================
  // Apps
  // ============================================================

  final Map<String, String> availableApps = {
    'com.whatsapp': 'WhatsApp',
    'com.whatsapp.w4b': 'WhatsApp Business',
    'com.google.android.apps.messaging': 'Google Messages',
    'com.instagram.android': 'Instagram',
    'com.slack': 'Slack',
    'com.android.email': 'Email',
    'com.google.android.gm': 'Gmail',
    'org.telegram.messenger': 'Telegram',
  };

  Set<String> selectedPackages = {
    'com.whatsapp',
    'com.whatsapp.w4b',
  };

  // ============================================================
  // Lifecycle
  // ============================================================

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addObserver(this);

    _loadSettings();

    Future.delayed(
      const Duration(milliseconds: 500),
      () {
        _checkNotificationAccess();
      },
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);

    scanSubscription?.cancel();

    connectionSubscription?.cancel();

    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(
    AppLifecycleState state,
  ) {
    if (state == AppLifecycleState.resumed) {
      debugPrint(
        "📱 DeskBuddy resumed",
      );

      Future.delayed(
        const Duration(milliseconds: 500),
        () {
          _checkNotificationAccess();
        },
      );
    }
  }

  // ============================================================
  // Load saved configuration
  // ============================================================

  Future<void> _loadSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final savedApps = prefs.getStringList(
        'selected_packages',
      );

      final savedAddress = prefs.getString(
        'esp32_address',
      );

      if (!mounted) return;

      setState(() {
        if (savedApps != null) {
          selectedPackages = savedApps.toSet();
        }

        if (savedAddress != null) {
          esp32Address = savedAddress;
        }
      });

      debugPrint(
        "📱 Selected apps: $selectedPackages",
      );

      debugPrint(
        "📡 Saved ESP32: $esp32Address",
      );
    } catch (e) {
      debugPrint(
        "❌ Failed loading settings: $e",
      );
    }
  }

  // ============================================================
  // Notification Access
  // ============================================================

  Future<void> _checkNotificationAccess() async {
    try {
      final bool granted = await nativeChannel.invokeMethod<bool>(
            'isNotificationAccessGranted',
          ) ??
          false;

      debugPrint(
        "🔐 Notification Access: $granted",
      );

      if (!mounted) return;

      setState(() {
        notificationAccessGranted = granted;
      });
    } catch (e) {
      debugPrint(
        "❌ Notification access check failed: $e",
      );
    }
  }

  Future<void> _openNotificationAccess() async {
    try {
      await nativeChannel.invokeMethod(
        'openNotificationAccess',
      );
    } catch (e) {
      debugPrint(
        "❌ Could not open notification access: $e",
      );
    }
  }

  // ============================================================
  // App selection
  // ============================================================

  Future<void> _toggleApp(
    String packageName,
    bool selected,
  ) async {
    if (selected) {
      selectedPackages.add(packageName);
    } else {
      selectedPackages.remove(packageName);
    }

    final prefs = await SharedPreferences.getInstance();

    await prefs.setStringList(
      'selected_packages',
      selectedPackages.toList(),
    );

    if (mounted) {
      setState(() {});
    }

    debugPrint(
      selected ? "✅ Enabled: $packageName" : "❌ Disabled: $packageName",
    );
  }

  // ============================================================
  // BLE Permissions
  // ============================================================

  Future<bool> _requestBluetoothPermissions() async {
    final results = await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
    ].request();

    if (await Permission.bluetoothScan.isDenied) {
      debugPrint(
        "❌ Bluetooth Scan permission denied",
      );

      return false;
    }

    if (await Permission.bluetoothConnect.isDenied) {
      debugPrint(
        "❌ Bluetooth Connect permission denied",
      );

      return false;
    }

    return results.values.every(
      (status) => status.isGranted || status.isLimited,
    );
  }

  // ============================================================
  // BLE Scan
  // ============================================================

  Future<void> _scanBle() async {
    final permitted = await _requestBluetoothPermissions();

    if (!permitted) {
      return;
    }

    try {
      await scanSubscription?.cancel();

      if (!mounted) return;

      setState(() {
        scanResults.clear();
        isScanning = true;
      });

      scanSubscription = FlutterBluePlus.scanResults.listen(
        (results) {
          if (!mounted) return;

          setState(() {
            scanResults = results;
          });
        },
        onError: (error) {
          debugPrint(
            "❌ BLE scan error: $error",
          );
        },
      );

      debugPrint(
        "🔍 BLE scan started",
      );

      await FlutterBluePlus.startScan(
        timeout: const Duration(seconds: 7),
      );

      debugPrint(
        "✅ BLE scan finished",
      );
    } catch (e) {
      debugPrint(
        "❌ BLE scan failed: $e",
      );
    } finally {
      if (mounted) {
        setState(() {
          isScanning = false;
        });
      }
    }
  }

  // ============================================================
  // Connect ESP32
  // ============================================================

  Future<void> _connectToEsp32(
    BluetoothDevice device,
  ) async {
    if (isConnecting) {
      return;
    }

    try {
      if (!mounted) return;

      setState(() {
        isConnecting = true;
      });

      debugPrint(
        "🔵 Connecting to ${device.remoteId}",
      );

      try {
        await device.connect(
          autoConnect: false,
        );
      } catch (e) {
        debugPrint(
          "ℹ️ Connection response: $e",
        );
      }

      await Future.delayed(
        const Duration(milliseconds: 500),
      );

      if (!mounted) return;

      setState(() {
        connectedDevice = device;
      });

      await connectionSubscription?.cancel();

      connectionSubscription = device.connectionState.listen(
        (state) {
          debugPrint(
            "🔵 BLE state: $state",
          );

          if (state == BluetoothConnectionState.disconnected) {
            if (!mounted) return;

            setState(() {
              connectedDevice = null;
              targetCharacteristic = null;
              currentMtu = 23;
            });
          }
        },
      );

      // ========================================================
      // Request MTU
      // ========================================================

      try {
        currentMtu = await device.requestMtu(512);

        debugPrint(
          "📏 MTU: $currentMtu",
        );
      } catch (e) {
        debugPrint(
          "ℹ️ MTU request failed: $e",
        );
      }

      // ========================================================
      // Discover services
      // ========================================================

      final services = await device.discoverServices();

      bool found = false;

      for (final service in services) {
        debugPrint(
          "Service: ${service.uuid}",
        );

        if (service.uuid.toString().toLowerCase() !=
            serviceUuid.toLowerCase()) {
          continue;
        }

        for (final characteristic in service.characteristics) {
          debugPrint(
            "Characteristic: "
            "${characteristic.uuid}",
          );

          if (characteristic.uuid.toString().toLowerCase() ==
              characteristicUuid.toLowerCase()) {
            if (!mounted) return;

            setState(() {
              targetCharacteristic = characteristic;
            });

            found = true;

            break;
          }
        }
      }

      if (!found) {
        debugPrint(
          "❌ ESP32 characteristic not found",
        );

        return;
      }

      // ========================================================
      // Save ESP32 address
      // ========================================================

      final address = device.remoteId.str;

      final prefs = await SharedPreferences.getInstance();

      await prefs.setString(
        'esp32_address',
        address,
      );

      if (!mounted) return;

      setState(() {
        esp32Address = address;
      });

      debugPrint(
        "💾 ESP32 address saved: $address",
      );

      // ========================================================
      // Tell native notification service
      // ========================================================

      try {
        await nativeChannel.invokeMethod(
          'setEsp32Address',
          {
            'address': address,
          },
        );

        debugPrint(
          "✅ Native BLE manager received ESP32 address",
        );
      } catch (e) {
        debugPrint(
          "❌ Failed sending address to native BLE: $e",
        );
      }

      debugPrint(
        "====================================",
      );

      debugPrint(
        "✅ ESP32 READY",
      );

      debugPrint("====================================");
    } catch (e, stack) {
      debugPrint(
        "❌ ESP32 connection failed: $e",
      );

      debugPrint(
        stack.toString(),
      );
    } finally {
      if (mounted) {
        setState(() {
          isConnecting = false;
        });
      }
    }
  }

  // ============================================================
  // Send test through Flutter BLE
  // ============================================================

  Future<void> _sendTest() async {
    if (connectedDevice == null || targetCharacteristic == null) {
      debugPrint(
        "❌ ESP32 not connected",
      );

      return;
    }

    await _sendBlePayload(
      "Ankush: Testing Desk Buddy!",
    );
  }

  // ============================================================
  // BLE write
  // ============================================================

  Future<void> _sendBlePayload(
    String message,
  ) async {
    final characteristic = targetCharacteristic;

    final device = connectedDevice;

    if (characteristic == null || device == null) {
      return;
    }

    try {
      final bytes = utf8.encode(message);

      final mtu = device.mtuNow > 3 ? device.mtuNow : currentMtu;

      final maxBytes = mtu - 3;

      List<int> data = List<int>.from(bytes);

      if (data.length > maxBytes) {
        data = data.sublist(
          0,
          maxBytes,
        );

        // Prevent broken UTF-8.
        while (data.isNotEmpty) {
          try {
            utf8.decode(data);
            break;
          } catch (_) {
            data.removeLast();
          }
        }
      }

      debugPrint(
        "📡 Flutter BLE SEND: "
        "${utf8.decode(
          data,
          allowMalformed: true,
        )}",
      );

      await characteristic.write(
        data,
        withoutResponse: false,
      );

      debugPrint(
        "✅ Flutter BLE write successful",
      );
    } catch (e) {
      debugPrint(
        "❌ Flutter BLE write failed: $e",
      );
    }
  }

  // ============================================================
  // Disconnect
  // ============================================================

  Future<void> _disconnect() async {
    try {
      await connectedDevice?.disconnect();
    } catch (_) {}

    if (!mounted) return;

    setState(() {
      connectedDevice = null;
      targetCharacteristic = null;
    });
  }

  // ============================================================
  // UI
  // ============================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Desk Buddy",
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ======================================================
          // Notification Access
          // ======================================================

          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Notification Access",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(
                        notificationAccessGranted
                            ? Icons.check_circle
                            : Icons.error,
                        color: notificationAccessGranted
                            ? Colors.green
                            : Colors.red,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          notificationAccessGranted ? "Enabled" : "Not enabled",
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: _openNotificationAccess,
                    icon: const Icon(
                      Icons.settings,
                    ),
                    label: const Text(
                      "Open Notification Access",
                    ),
                  ),
                  const SizedBox(height: 6),
                  TextButton(
                    onPressed: _checkNotificationAccess,
                    child: const Text(
                      "Check Again",
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          // ======================================================
          // ESP32
          // ======================================================

          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "ESP32",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    connectedDevice != null ? "Connected" : "Disconnected",
                  ),
                  if (esp32Address.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(
                        top: 4,
                      ),
                      child: Text(
                        "Address: "
                        "$esp32Address",
                        style: const TextStyle(
                          fontSize: 12,
                        ),
                      ),
                    ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: isScanning ? null : _scanBle,
                          child: Text(
                            isScanning ? "Scanning..." : "Scan BLE",
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton(
                          onPressed:
                              connectedDevice != null ? _disconnect : null,
                          child: const Text(
                            "Disconnect",
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton.icon(
                    onPressed: targetCharacteristic != null ? _sendTest : null,
                    icon: const Icon(
                      Icons.send,
                    ),
                    label: const Text(
                      "SEND TEST NOTIFICATION",
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          // ======================================================
          // Devices
          // ======================================================

          const Text(
            "Bluetooth Devices",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 17,
            ),
          ),

          const SizedBox(height: 8),

          if (scanResults.isEmpty)
            const Text(
              "No devices found.",
            ),

          ...scanResults.map(
            (result) {
              final name = result.device.platformName;

              return ListTile(
                leading: const Icon(
                  Icons.bluetooth,
                ),
                title: Text(
                  name.isEmpty ? "Unknown Device" : name,
                ),
                subtitle: Text(
                  "${result.device.remoteId.str}\n"
                  "${result.rssi} dBm",
                ),
                isThreeLine: true,
                trailing: ElevatedButton(
                  onPressed: isConnecting
                      ? null
                      : () => _connectToEsp32(
                            result.device,
                          ),
                  child: Text(
                    isConnecting ? "..." : "Connect",
                  ),
                ),
              );
            },
          ),

          const Divider(
            height: 35,
          ),

          // ======================================================
          // Notification Apps
          // ======================================================

          const Text(
            "Notification App Routing",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 17,
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            "Only selected apps will be forwarded "
            "to the Desk Buddy.",
            style: TextStyle(
              color: Colors.grey,
            ),
          ),

          const SizedBox(height: 8),

          ...availableApps.entries.map(
            (entry) {
              return CheckboxListTile(
                title: Text(entry.value),
                subtitle: Text(entry.key),
                value: selectedPackages.contains(
                  entry.key,
                ),
                onChanged: (value) {
                  _toggleApp(
                    entry.key,
                    value ?? false,
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
